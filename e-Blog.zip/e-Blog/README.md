# E-Commerse
This is simple E-Commerce website made using html and css only